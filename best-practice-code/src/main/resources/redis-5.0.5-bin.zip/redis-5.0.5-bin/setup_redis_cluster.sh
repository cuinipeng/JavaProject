#!/bin/bash

function precheck()
{
    sysctl vm.overcommit_memory=1 > /dev/null
    # echo 'vm.overcommit_memory = 1' >> /etc/sysctl.conf
    echo 512 > /proc/sys/net/core/somaxconn
    echo never > /sys/kernel/mm/transparent_hugepage/enabled
}

function init_redis_cluster()
{
    redis-cli --cluster create --cluster-replicas 1 \
        192.168.100.135:4379 192.168.100.135:5379 192.168.100.135:6379 \
        192.168.100.135:7379 192.168.100.135:8379 192.168.100.135:9379
}

function start()
{
    redis-server ./conf/redis_4379.conf
    redis-server ./conf/redis_5379.conf
    redis-server ./conf/redis_6379.conf
    redis-server ./conf/redis_7379.conf
    redis-server ./conf/redis_8379.conf
    redis-server ./conf/redis_9379.conf
}

function stop()
{
    redis_pids=$(ps -ef | grep redis-server | grep -v grep | awk '{print $2}')
    kill -9 ${redis_pids}
}

function status()
{
    ps -ef | grep redis-server | grep -v grep
    netstat -ntlp | grep redis-server | grep -v grep
}

function test()
{
    redis-server ./conf/redis.conf
}

function main()
{
    precheck
    action="$1"
    case "${action}" in
        init)
            init_redis_cluster
            ;;
        start)
            start
            ;;
        stop)
            stop
            ;;
        status)
            status
            ;;
        test)
            test
            ;;
        *)
            echo "$0 [init|start|stop|status|test]"
            ;;
    esac
}

main $@

